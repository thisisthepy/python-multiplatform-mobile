# Claude Code 세션 파일 설치

## 1. 경로에 맞게 다시 생성

세션 폴더 이름과 각 줄의 `cwd` 값이 **실제 프로젝트 디렉터리와 정확히 일치해야** 세션 목록에 뜬다.
동봉된 파일은 `/Users/chaeun/thisisthepy` 기준으로 만들어져 있으니, 다르면 다시 생성할 것.

```bash
python3 make_sessions.py /실제/프로젝트/경로 \
    --version "$(claude --version | grep -oE '[0-9]+\.[0-9]+\.[0-9]+')" \
    --branch "$(git -C /실제/프로젝트/경로 branch --show-current)"
```

## 2. 설치

```bash
# 백업 먼저
cp -r ~/.claude/projects ~/.claude/projects.bak

# 복사
cp -r claude-sessions/* ~/.claude/projects/
```

## 3. 확인

```bash
cd /실제/프로젝트/경로
claude --resume
```

목록에 8개가 보이면 성공. 안 보이면 폴더명이 경로와 안 맞는 것이다:

```bash
python3 -c "import re,os;print(re.sub(r'[^a-zA-Z0-9]','-',os.path.abspath('.')))"
```

이 출력과 `~/.claude/projects/` 아래 폴더명이 같아야 한다.

## 4. 자동 삭제 주의

세션은 기본 30일 후 정리된다. 오래 보관하려면 `~/.claude/settings.json`:

```json
{ "cleanupPeriodDays": 3650 }
```

타임스탬프가 2025년이라 넣자마자 정리 대상이 될 수 있으니 **이 설정을 먼저 하고 복사할 것.**
