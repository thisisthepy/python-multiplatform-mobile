#!/usr/bin/env python3
"""
Claude 웹 백업 대화를 Claude Code 세션 JSONL로 변환.

    python3 make_sessions.py /path/to/your/project [--version 2.1.230] [--branch main]

결과는 ./claude-sessions/<munged-cwd>/<session-id>.jsonl 로 나온다.
그대로 ~/.claude/projects/ 아래에 복사하면 `claude --resume` 목록에 뜬다.

주의: 이 JSONL 항목 포맷은 Claude Code 내부 규격이며 버전마다 바뀔 수 있다
(공식 문서 명시). 실제 세션 파일과 대조해 확인할 것.
"""
import argparse, json, os, re, uuid, sys

SRC = ["/home/claude/ex/conv/conversations.json",
       "/home/claude/ex/batch0/conversations.json"]

TARGETS = [
    "1b3a70d5-ab60-403e-b466-6503efa6db4f",  # 파이썬 바인더 설계도
    "0789e5c5-89dc-4cf7-85fe-cf5836e1767c",  # 파이썬 바인더 메모리 관리
    "cc0629d9-763d-41c9-be37-25b01cd62b29",  # 코틀린 변환 컨택스트
    "66cf5fbc-c1de-4076-8671-ff8e359236a5",  # 코틀린 파이썬 타입 상속
    "151db2a4-1206-4627-9c1d-8fd83b8bd572",  # 파이썬 wheel 파일 규정
    "707daf18-726a-43a7-a0d4-bb9c3f410ff2",  # 파이썬 람다 @Composable
    "a7315aa8-19b2-492e-b426-a026f67a4e8a",  # JNI Free 구현
    "cac41635-3693-49f0-8c67-44bf532c3d7a",  # Jetpack Compose와 Swing
]

NS = uuid.UUID("6ba7b810-9dad-11d1-80b4-00c04fd430c8")


def det_uuid(*parts):
    """원본 UUID에서 결정적으로 새 UUID 생성 — 재실행해도 동일."""
    return str(uuid.uuid5(NS, "|".join(parts)))


def munge(path):
    """작업 디렉터리 경로 → 프로젝트 폴더명."""
    return re.sub(r"[^a-zA-Z0-9]", "-", os.path.abspath(path))


def ts(s):
    return s.replace("Z", "").split(".")[0] + ".000Z"


def load():
    seen, db = set(), {}
    for p in SRC:
        for c in json.load(open(p)):
            if c["uuid"] not in seen:
                seen.add(c["uuid"])
                db[c["uuid"]] = c
    return db


def text_of(m):
    parts = []
    for b in m.get("content") or []:
        if b.get("type") == "text" and b.get("text", "").strip():
            parts.append(b["text"].strip())
    if not parts and m.get("text", "").strip():
        parts.append(m["text"].strip())
    for a in (m.get("attachments") or []):
        fn = a.get("file_name", "attachment")
        ec = a.get("extracted_content", "")
        if ec:
            parts.append(f"[첨부 파일: {fn}]\n\n```\n{ec.rstrip()}\n```")
        else:
            parts.append(f"[첨부 파일: {fn}]")
    return "\n\n".join(parts)


def build(conv, cwd, version, branch, model):
    sid = det_uuid("session", conv["uuid"])
    lines, parent = [], None

    for m in conv["chat_messages"]:
        body = text_of(m)
        if not body:
            continue
        muid = det_uuid("msg", m["uuid"])
        base = {
            "parentUuid": parent,
            "isSidechain": False,
            "userType": "external",
            "cwd": cwd,
            "sessionId": sid,
            "version": version,
            "gitBranch": branch,
            "uuid": muid,
            "timestamp": ts(m["created_at"]),
        }
        if m["sender"] == "human":
            base["type"] = "user"
            base["message"] = {"role": "user",
                               "content": [{"type": "text", "text": body}]}
        else:
            base["type"] = "assistant"
            base["message"] = {
                "id": "msg_" + det_uuid("api", m["uuid"]).replace("-", "")[:24],
                "type": "message",
                "role": "assistant",
                "model": model,
                "content": [{"type": "text", "text": body}],
                "stop_reason": "end_turn",
                "stop_sequence": None,
                "usage": {"input_tokens": 0, "output_tokens": 0,
                          "cache_creation_input_tokens": 0,
                          "cache_read_input_tokens": 0,
                          "service_tier": "standard"},
            }
            base["requestId"] = "req_" + det_uuid("req", m["uuid"]).replace("-", "")[:24]
        lines.append(base)
        parent = muid

    if not lines:
        return sid, []
    # 세션 목록에 표시될 요약 줄 (파일 맨 앞)
    head = {"type": "summary",
            "summary": conv["name"] or "Untitled",
            "leafUuid": lines[-1]["uuid"]}
    return sid, [head] + lines


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("cwd", help="이 세션들이 속할 프로젝트 디렉터리 (절대경로)")
    ap.add_argument("--version", default="2.1.230",
                    help="claude --version 결과와 맞출 것")
    ap.add_argument("--branch", default="main")
    ap.add_argument("--model", default="claude-sonnet-4-6")
    ap.add_argument("--out", default="/home/claude/out3/claude-sessions")
    a = ap.parse_args()

    cwd = os.path.abspath(a.cwd)
    outdir = os.path.join(a.out, munge(cwd))
    os.makedirs(outdir, exist_ok=True)

    db = load()
    for cid in TARGETS:
        conv = db[cid]
        sid, lines = build(conv, cwd, a.version, a.branch, a.model)
        if not lines:
            print(f"skip (내용 없음): {conv['name']}", file=sys.stderr)
            continue
        path = os.path.join(outdir, sid + ".jsonl")
        with open(path, "w") as f:
            for ln in lines:
                f.write(json.dumps(ln, ensure_ascii=False) + "\n")
        print(f"{sid}.jsonl  {len(lines) - 1:3}줄  {conv['name']}")

    print(f"\n→ {outdir}")


if __name__ == "__main__":
    main()
